const SerialPort = require('serialport');
const Readline = require('@serialport/parser-readline');

const port = new SerialPort('COM4', { baudRate: 115200 });
const parser = port.pipe(new Readline({ delimiter: '\n' }));

// Read the port data
port.on("open", () => {
    console.log('serial port open');
});

port.write('on\r', (err) => {
    if (err) {
        return console.log('Error on write: ', err.message);
    }
    readSerialData(err);
    console.log('message written');
});

parser.on('data', data =>{
    console.log('got word from node:', data);
});

function readSerialData(data) {
    console.log(data);
}

